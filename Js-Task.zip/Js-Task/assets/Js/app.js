$(document).ready(function () {
  let addItemBtn = $("#add-item");
  let form = $("#category-form");
  let Categorys = [];
  let id = 0;
  let deleteConfirm = $("#delete-confirm");
  let deletableCategory;
  let itemCount = 1;
  let isDelete = false;
  let isEdit = false;
  let isDeleteItem = false;
  let tempCategory = {};
  let date = new Date();
  let launchDate = $("#launch-date");
  let currentDate = date.toLocaleDateString("en-CA");

  launchDate.attr("max", currentDate);

  $("#modalId").on("show.bs.modal", function () {
    let items = $(".items");
    let item = items.find(".item");
    $("#submit").text("Submit");
    itemCount = 1;

    item.slice(1).remove();

    form[0].reset();
  });

  //Calculate Discount Function
  function disCount(Price, Discount) {
    let price = parseFloat(Price.val());
    let discount = parseFloat(Discount.val());

    if (price * discount == 0) {
      return price.toFixed(2);
    } else {
      return (price - (price * discount) / 100).toFixed(2);
    }
  }

  //Date Diffrence Calculate Function
  function dateDiff(launchDate, currentDate) {
    let date1 = new Date(launchDate);
    let date2 = new Date(currentDate);

    let date1_ms = date1.getTime();
    let date2_ms = date2.getTime();

    let differnce_ms = Math.abs(date2_ms - date1_ms);

    let dayDiff = Math.floor(differnce_ms / (1000 * 60 * 60 * 24));
    return dayDiff;
  }

  //Array Copy
  function deepCloneArray(arr) {
    return JSON.parse(JSON.stringify(arr));
  }

  //Nagative Value Handle Function
  function negativeHandle(elem) {
    if (elem.val().charAt(0) == "-") {
      elem.val("0");
    }
  }

  //Nagative Value Handling
  form.on("change", 'input[type="number"]', function () {
    negativeHandle($(this));
  });

  //More Item Adding
  function itemAdd(c) {
    let items = $(".items").find(".item");
    if (items.length >= 10) return;
    let count = 0;
    while (count < c) {
      let item = $(".item:last-of-type").clone();
      item.find("#item-id").text("");
      item.find("input").val("");
      $(".items").append(item);
      itemCount++;
      count++;
    }
  }
  addItemBtn.on("click", function () {
    itemAdd(1);
  });

  //Item Removing
  form.on("click", "#remove-item", function (e) {
    e.preventDefault();
    let filed = $(this).closest(".item");

    let items = $(".items").find(".item");

    if (items.length <= 1) return;

    if (!isEdit) {
      filed.remove();
      itemCount -= 1;
    } else {
      let itemId = $(this).closest(".item").find("#item-id").text();
      // let itemName = item.find("#item-name").val();
      let index = tempCategory.items.findIndex((s) => s.itemId == itemId);
      tempCategory.items[index].deleteItem = true;
      tempCategory.itemCount -= 1;
      itemCount -= 1;
      filed.remove();
    }
  });

  //Invalid Input red error
  form.on("change", "input", function () {
    if ($(this).is(":invalid")) {
      $(this).next().addClass("invalid");
      $(this).next().removeClass("valid");
    } else {
      $(this).next().removeClass("invalid");
      $(this).next().addClass("valid");
    }
  });
  //Main Data Table
  let mainTable = $("#main-table").DataTable({
    columns: [
      { data: "catId", visible: false },
      { data: "show" },
      { data: "catName" },
      { data: "catDesc" },
      { data: "catAvail" },
      { data: "new" },
      { data: "action" },
    ],
  });

  //Show Data In MAin Data Table Function
  function showData(e) {
    mainTable.clear().draw();
    let btn = ` <div class="d-flex"><button
    type="button"
    id="edit"
    class="btn btn-success"
    data-bs-toggle="modal"
    data-bs-target="#modalId"
  >
    Edit
  </button><button id="delete" class="btn btn-danger ms-3">Delete</button></div>`;
    let show = `<button class="btn btn-success" id="show">show</button>`;
    Categorys.forEach(function (cat) {
      if (!cat.deleteCategory) {
        let categoryStatus =
          dateDiff(cat.catDate, currentDate) < 7 ? "New" : "Old";
        let obj = {
          catId: cat.catId,
          show: show,
          catName: cat.catName,
          catDesc: cat.catDesc,
          catAvail: cat.catAvail,
          new: categoryStatus,
          action: btn,
          items: cat.items,
        };
        mainTable.row.add(obj).draw();
      }
    });
  }

  //Child Table Showing
  mainTable.on("click", "#show", function (e) {
    e.preventDefault();
    let tr = $(this).closest("tr");
    let row = mainTable.row(tr);

    if (row.child.isShown()) {
      row.child.hide();
    } else {
      let itemsTb = deepCloneArray(row.data().items);
      let priceTotal = 0;
      let discountedTotal = 0;

      let avilItem = itemsTb.filter((item) => !item.deleteItem);

      avilItem.forEach(function (item, index) {
        item.number = index + 1;
        priceTotal += parseFloat(item.itemPrice);
        discountedTotal += parseFloat(item.itemDiscPrice);
        item.itemDiscount = item.itemDiscount + "%";
      });

      let childTable =
        $(`  <table id="child-table"><thead> <th>Number</th> <th>Item name</th> <th>Food type</th>
                                             <th>Price</th> <th>Discount</th><th>Discounted price</th>
                                             </thead><tbody></tbody><tfoot><tr><td>Total</td>
                                             <td></td><td></td><td>${priceTotal.toFixed(
                                               2
                                             )}</td><td></td><td>${discountedTotal.toFixed(
          2
        )}</td></tr></tfoot> </table>`);

      row.child(childTable).show();
      childTable.DataTable({
        columns: [
          { data: "number" },
          { data: "itemName" },
          { data: "itemType" },
          { data: "itemPrice" },
          { data: "itemDiscount" },
          { data: "itemDiscPrice" },
        ],
        data: avilItem,
        paging: false,
        searching: false,
      });
    }
  });

  //Edit Category
  mainTable.on("click", "#edit", function (e) {
    e.preventDefault();
    isEdit = true;
    $("#submit").text("Update");
    let tr = $(this).closest("tr");
    let row = mainTable.row(tr);
    let id = row.data().catId;
    let index = Categorys.findIndex((s) => s.catId == id);
    tempCategory = Categorys[index];
    itemCount = tempCategory.itemCount;
    itemAdd(itemCount - 1);
    itemCount = tempCategory.itemCount;
    let itemMainContainer = $(".items");
    let items = itemMainContainer.find(".item");
    $("#category-name").val(tempCategory.catName);
    $("#category-description").val(tempCategory.catDesc);
    $("#launch-date").val(tempCategory.catDate);
    tempCategory.catAvail == "No"
      ? $("#active").prop("checked", false)
      : $("#active").prop("checked", true);

    let i = 0;
    items.each(function (index) {
      while (tempCategory.items[i].deleteItem) {
        i++;
      }
      let item = tempCategory.items[i];
      $(this).find("#item-id").text(item.itemId);
      $(this).find("#item-name").val(item.itemName);
      $(this).find("#item-description").val(item.itemDesc);
      $(this).find("#food-type").val(item.itemType);
      $(this).find("#price").val(item.itemPrice);
      $(this).find("#discount").val(item.itemDiscount);
      $(this).find("#gst").val(item.itemGST);
      i++;
    });
  });

  deleteConfirm.on("click", function () {
    deleteCat(deletableCategory);
  });

  function deleteCat(obj) {
    obj.deleteCategory = true;
    console.log(Categorys);
    showData();
  }
  //Delete Category
  mainTable.on("click", "#delete", function (e) {
    e.preventDefault();
    $("#delete-confirmation-modal").modal("show");
    let Name = $(this).closest("tr").find("td").eq(1).text();
    let index = Categorys.findIndex((s) => s.catName == Name);
    let deleteCategory = Categorys[index];
    deletableCategory = deleteCategory;
    // deleteCat(deleteCategory);
    // deleteCategory.deleteCategory = true;
    // console.log(Categorys);
    // showData();
  });

  form.on("submit", function (e) {
    e.preventDefault();
    let categoryName = $("#category-name");
    let categoryDescription = $("#category-description");
    let catAvilable = $("#active").prop("checked") ? "Yes" : "No";
    let launchDate = $("#launch-date");
    let itemMainContainer = $(".items");
    let items = itemMainContainer.find(".item");
    let itemsArr = [];

    if (!isEdit) {
      id += 1;
      let itemId = 1;
      items.each(function () {
        let item = {
          itemId: itemId,
          deleteItem: isDeleteItem,
          itemName: $(this).find("#item-name").val(),
          itemDesc: $(this).find("#item-description").val(),
          itemType: $(this).find("#food-type").val(),
          itemPrice: parseFloat($(this).find("#price").val()).toFixed(2),
          itemDiscount: parseFloat($(this).find("#discount").val()).toFixed(2),
          itemGST: parseFloat($(this).find("#gst").val()).toFixed(2),
          itemDiscPrice: disCount(
            $(this).find("#price"),
            $(this).find("#discount")
          ),
        };
        itemsArr.push(item);
        itemId += 1;
      });

      let Category = {
        catId: id,
        deleteCategory: isDelete,
        itemCount: itemCount,
        catName: categoryName.val(),
        catDesc: categoryDescription.val(),
        catAvail: catAvilable,
        catDate: launchDate.val(),
        items: itemsArr,
      };
      Categorys.push(Category);
    } else {
      isEdit = false;
      tempCategory.catName = categoryName.val();
      tempCategory.catDesc = categoryDescription.val();
      tempCategory.catAvail = catAvilable;
      tempCategory.catDate = launchDate.val();

      let i = 0;
      let items = $(".items").find(".item");
      let totalItems = tempCategory.items.length;
      items.each(function (index) {
        if (index < tempCategory.itemCount) {
          while (tempCategory.items[i].deleteItem) {
            i++;
          }
          let item = tempCategory.items[i];

          item.itemName = $(this).find("#item-name").val();
          item.itemDesc = $(this).find("#item-description").val();
          item.itemType = $(this).find("#food-type").val();
          item.itemPrice = parseFloat($(this).find("#price").val()).toFixed(2);
          item.itemDiscount = parseFloat(
            $(this).find("#discount").val()
          ).toFixed(2);
          item.itemGST = parseFloat($(this).find("#gst").val()).toFixed(2);
          item.itemDiscPrice = disCount(
            $(this).find("#price"),
            $(this).find("#discount")
          );
          i++;
        } else {
          let item = {
            itemId: totalItems + 1,
            deleteItem: isDeleteItem,
            itemName: $(this).find("#item-name").val(),
            itemDesc: $(this).find("#item-description").val(),
            itemType: $(this).find("#food-type").val(),
            itemPrice: parseFloat($(this).find("#price").val()).toFixed(2),
            itemDiscount: parseFloat($(this).find("#discount").val()).toFixed(
              2
            ),
            itemGST: parseFloat($(this).find("#gst").val()).toFixed(2),
            itemDiscPrice: disCount(
              $(this).find("#price"),
              $(this).find("#discount")
            ),
          };
          tempCategory.items.push(item);
          totalItems += 1;
        }
      });

      tempCategory.itemCount = itemCount;
    }

    if (this.checkValidity() === false) {
      e.stopPropagation();
    } else {
      // Close the modal if form data is valid
      $("#modalId").modal("hide");
    }
    console.log(Categorys);
    $("#category-form")[0].reset();
    showData();
  });
});
// let Ids = ["option1", "option3"];
// $("#check").on("click", function () {
//   let checkboxes = $('input[name="operation"]:checked');
//   let Ids = [];
//   checkboxes.each(function () {
//     Ids.push($(this).attr("value"));
//   });
//   console.log(Ids);
// });

// $("#check-edit").on("click", function () {
//   Ids.forEach(function (value) {
//     let check = $('input[name="operation"][value="' + value + '"]');

//     check.prop("checked", true);
//   });
// });

// $("#check").on("click", function () {
//   let checkedRadio = $('input[name="food"]:checked');
//   console.log(checkedRadio.attr("id"));
// });

// $("#check-edit").on("click", function () {
//   let check = $('input[name="food"][id="' + idr + '"]');
//   check.prop("checked", true);
// });
