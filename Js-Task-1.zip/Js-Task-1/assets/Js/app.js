$(document).ready(function () {
  console.log("ok");
});
